import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';
import TabNavigation from './components/TabNavigation';
import AppsList from './components/AppsList';
import AppDetails from './components/AppDetails';
import ManageApps from './components/ManageApps';
import { IApp } from './types';

function App() {
  const [activeTab, setActiveTab] = useState('apps');
  const [apps, setApps] = useState<IApp[]>([]);
  const [selectedApp, setSelectedApp] = useState<IApp | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    packageName: '',
    description: '',
    developer: '',
    versionNumber: '',
    versionCode: '',
    changelog: '',
  });
  const [files, setFiles] = useState({
    apk: null as File | null,
    icon: null as File | null,
    screenshots: [] as File[],
  });

  useEffect(() => {
    fetchApps();
  }, []);

  const fetchApps = async () => {
    try {
      const response = await axios.get('http://192.168.50.96:3011/api/apps');
      setApps(response.data);
    } catch (error) {
      console.error('Error fetching apps:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const submitData = new FormData();
    submitData.append('appData', JSON.stringify(formData));
    
    if (files.apk) submitData.append('apk', files.apk);
    if (files.icon) submitData.append('icon', files.icon);
    files.screenshots.forEach(screenshot => {
      submitData.append('screenshots', screenshot);
    });

    try {
      await axios.post('http://192.168.50.96:3011/api/apps', submitData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      fetchApps();
      resetForm();
      alert('App uploaded successfully!');
    } catch (error) {
      console.error('Error uploading app:', error);
      alert('Error uploading app');
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      packageName: '',
      description: '',
      developer: '',
      versionNumber: '',
      versionCode: '',
      changelog: '',
    });
    setFiles({
      apk: null,
      icon: null,
      screenshots: [],
    });
  };

  return (
    <div className="App">
      <h1>App Store Management</h1>
      
      <TabNavigation activeTab={activeTab} setActiveTab={setActiveTab} />

      {activeTab === 'apps' && !selectedApp && (
        <AppsList apps={apps} onAppClick={setSelectedApp} />
      )}

      {selectedApp && (
        <AppDetails app={selectedApp} onClose={() => setSelectedApp(null)} />
      )}

      {activeTab === 'upload' && (
        <div className="upload-form">
          <h2>Upload New App</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              placeholder="App Name"
              value={formData.name}
              onChange={e => setFormData({...formData, name: e.target.value})}
            />
            <input
              type="text"
              placeholder="Package Name"
              value={formData.packageName}
              onChange={e => setFormData({...formData, packageName: e.target.value})}
            />
            <textarea
              placeholder="Description"
              value={formData.description}
              onChange={e => setFormData({...formData, description: e.target.value})}
            />
            <input
              type="text"
              placeholder="Developer"
              value={formData.developer}
              onChange={e => setFormData({...formData, developer: e.target.value})}
            />
            <input
              type="text"
              placeholder="Version Number"
              value={formData.versionNumber}
              onChange={e => setFormData({...formData, versionNumber: e.target.value})}
            />
            <textarea
              placeholder="Changelog"
              value={formData.changelog}
              onChange={e => setFormData({...formData, changelog: e.target.value})}
            />
            
            <div className="file-inputs">
              <div>
                <label>APK File:</label>
                <input
                  type="file"
                  accept=".apk"
                  onChange={e => setFiles({...files, apk: e.target.files?.[0] || null})}
                />
              </div>
              <div>
                <label>Icon:</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={e => setFiles({...files, icon: e.target.files?.[0] || null})}
                />
              </div>
              <div>
                <label>Screenshots:</label>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={e => setFiles({
                    ...files,
                    screenshots: Array.from(e.target.files || [])
                  })}
                />
              </div>
            </div>
            
            <button type="submit">Upload App</button>
          </form>
        </div>
      )}

      {activeTab === 'manage' && (
        <ManageApps apps={apps} onAppDeleted={fetchApps} />
      )}
    </div>
  );
}

export default App; 