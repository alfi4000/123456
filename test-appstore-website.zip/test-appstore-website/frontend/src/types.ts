export interface IApp {
  _id: string;
  name: string;
  packageName: string;
  description: string;
  developer: string;
  icon: string;
  versions: {
    versionNumber: string;
    versionCode: number;
    changelog: string;
    apkFile: string;
    screenshots: string[];
    uploadDate: string;
  }[];
} 