import React, { useState } from 'react';
import { AppCard, AppDetails, Button } from './StyledComponents';
import { IApp } from '../types';

interface AppsListProps {
  apps: IApp[];
  onAppClick: (app: IApp) => void;
}

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3011';

const AppsList: React.FC<AppsListProps> = ({ apps, onAppClick }) => {
  return (
    <div className="apps-grid">
      {apps.map(app => (
        <AppCard key={app._id} onClick={() => onAppClick(app)}>
          <img src={`${API_URL}${app.icon}`} alt={app.name} className="app-icon" />
          <AppDetails>
            <h3>{app.name}</h3>
            <p>{app.description}</p>
            <p>Developer: {app.developer}</p>
            <p>Latest Version: {app.versions[0]?.versionNumber}</p>
          </AppDetails>
        </AppCard>
      ))}
    </div>
  );
};

export default AppsList; 