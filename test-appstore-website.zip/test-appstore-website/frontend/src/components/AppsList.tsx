import React, { useState } from 'react';
import { AppCard, AppDetails, Button } from './StyledComponents';
import { IApp } from '../types';

interface AppsListProps {
  apps: IApp[];
  onAppClick: (app: IApp) => void;
}

const AppsList: React.FC<AppsListProps> = ({ apps, onAppClick }) => {
  return (
    <div className="apps-grid">
      {apps.map(app => (
        <AppCard key={app._id} onClick={() => onAppClick(app)}>
          <img src={`http://192.168.50.96:3011${app.icon}`} alt={app.name} className="app-icon" />
          <AppDetails>
            <h3>{app.name}</h3>
            <p>{app.description}</p>
            <p>Developer: {app.developer}</p>
            <p>Latest Version: {app.versions[0]?.versionNumber}</p>
          </AppDetails>
        </AppCard>
      ))}
    </div>
  );
};

export default AppsList; 