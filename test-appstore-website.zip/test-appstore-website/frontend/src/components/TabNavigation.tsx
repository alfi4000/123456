import React from 'react';
import { Tab, Tabs } from './StyledComponents';

interface TabNavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const TabNavigation: React.FC<TabNavigationProps> = ({ activeTab, setActiveTab }) => {
  return (
    <Tabs>
      <Tab
        active={activeTab === 'apps'}
        onClick={() => setActiveTab('apps')}
      >
        Apps List
      </Tab>
      <Tab
        active={activeTab === 'upload'}
        onClick={() => setActiveTab('upload')}
      >
        Upload App
      </Tab>
      <Tab
        active={activeTab === 'update'}
        onClick={() => setActiveTab('update')}
      >
        Update App
      </Tab>
      <Tab
        active={activeTab === 'manage'}
        onClick={() => setActiveTab('manage')}
      >
        Manage Apps
      </Tab>
    </Tabs>
  );
};

export default TabNavigation; 