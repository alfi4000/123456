import React, { useState } from 'react';
import { IApp } from '../types';
import { Button, DeleteCard } from './StyledComponents';
import axios from 'axios';
import { API_URL } from '../config';

interface ManageAppsProps {
  apps: IApp[];
  onAppDeleted: () => void;
}

const ManageApps: React.FC<ManageAppsProps> = ({ apps, onAppDeleted }) => {
  const [selectedApp, setSelectedApp] = useState<string>('');
  const [selectedVersion, setSelectedVersion] = useState<string>('');

  const handleDeleteVersion = async () => {
    if (!selectedApp || !selectedVersion) return;
    
    try {
      await axios.delete(`${API_URL}/api/apps/${selectedApp}/versions/${selectedVersion}`);
      onAppDeleted();
      alert('Version deleted successfully');
    } catch (error) {
      console.error('Error deleting version:', error);
      alert('Error deleting version');
    }
  };

  const handleDeleteApp = async () => {
    if (!selectedApp) return;
    
    try {
      await axios.delete(`${API_URL}/api/apps/${selectedApp}`);
      onAppDeleted();
      alert('App deleted successfully');
    } catch (error) {
      console.error('Error deleting app:', error);
      alert('Error deleting app');
    }
  };

  return (
    <div className="manage-apps">
      <DeleteCard>
        <h3>Delete App Version</h3>
        <select 
          value={selectedApp} 
          onChange={(e) => setSelectedApp(e.target.value)}
        >
          <option value="">Select App</option>
          {apps.map(app => (
            <option key={app._id} value={app._id}>{app.name}</option>
          ))}
        </select>

        {selectedApp && (
          <select 
            value={selectedVersion} 
            onChange={(e) => setSelectedVersion(e.target.value)}
          >
            <option value="">Select Version</option>
            {apps.find(app => app._id === selectedApp)?.versions.map(version => (
              <option key={version.versionNumber} value={version.versionNumber}>
                {version.versionNumber}
              </option>
            ))}
          </select>
        )}

        <Button onClick={handleDeleteVersion} disabled={!selectedVersion}>
          Delete Version
        </Button>
      </DeleteCard>

      <DeleteCard>
        <h3>Delete Entire App</h3>
        <select 
          value={selectedApp} 
          onChange={(e) => setSelectedApp(e.target.value)}
        >
          <option value="">Select App</option>
          {apps.map(app => (
            <option key={app._id} value={app._id}>{app.name}</option>
          ))}
        </select>

        <Button 
          onClick={handleDeleteApp} 
          disabled={!selectedApp}
          className="delete-button"
        >
          Delete App
        </Button>
      </DeleteCard>
    </div>
  );
};

export default ManageApps; 