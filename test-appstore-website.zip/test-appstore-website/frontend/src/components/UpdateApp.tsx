import React, { useState } from 'react';
import { IApp } from '../types';
import { API_URL } from '../config';
import axios from 'axios';
import styled from 'styled-components';
import { Button } from './StyledComponents';

interface UpdateAppProps {
  apps: IApp[];
  onAppUpdated: () => void;
}

const UpdateApp: React.FC<UpdateAppProps> = ({ apps, onAppUpdated }) => {
  const [selectedApp, setSelectedApp] = useState<string>('');
  const [formData, setFormData] = useState({
    versionNumber: '',
    versionCode: 1,
    changelog: '',
  });
  const [files, setFiles] = useState({
    apk: null as File | null,
    screenshots: [] as File[],
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedApp) {
      alert('Please select an app to update');
      return;
    }

    const submitData = new FormData();
    submitData.append('versionData', JSON.stringify(formData));
    
    if (files.apk) submitData.append('apk', files.apk);
    files.screenshots.forEach(screenshot => {
      submitData.append('screenshots', screenshot);
    });

    try {
      await axios.post(`${API_URL}/api/apps/${selectedApp}/versions`, submitData, {
        headers: { 'Content-Type': 'multipart/form-data' },
      });
      onAppUpdated();
      resetForm();
      alert('App version updated successfully!');
    } catch (error) {
      console.error('Error updating app:', error);
      alert('Error updating app');
    }
  };

  const resetForm = () => {
    setSelectedApp('');
    setFormData({
      versionNumber: '',
      versionCode: 1,
      changelog: '',
    });
    setFiles({
      apk: null,
      screenshots: [],
    });
  };

  return (
    <UpdateFormContainer>
      <h2>Update App Version</h2>
      <form onSubmit={handleSubmit}>
        <FormGroup>
          <Label>Select App</Label>
          <Select
            value={selectedApp}
            onChange={(e) => setSelectedApp(e.target.value)}
            required
          >
            <option value="">Select App to Update</option>
            {apps.map(app => (
              <option key={app._id} value={app._id}>
                {app.name} (Current version: {app.versions[0]?.versionNumber})
              </option>
            ))}
          </Select>
        </FormGroup>

        <FormGroup>
          <Label>New Version Number</Label>
          <Input
            type="text"
            placeholder="e.g., 1.0.1"
            value={formData.versionNumber}
            onChange={e => setFormData({...formData, versionNumber: e.target.value})}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label>Version Code</Label>
          <Input
            type="number"
            placeholder="Must be higher than current"
            value={formData.versionCode}
            onChange={e => setFormData({...formData, versionCode: parseInt(e.target.value)})}
            min="1"
            required
          />
        </FormGroup>

        <FormGroup>
          <Label>Changelog</Label>
          <TextArea
            placeholder="What's new in this version?"
            value={formData.changelog}
            onChange={e => setFormData({...formData, changelog: e.target.value})}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label>APK File</Label>
          <FileInput
            type="file"
            accept=".apk"
            onChange={e => setFiles({...files, apk: e.target.files?.[0] || null})}
            required
          />
        </FormGroup>

        <FormGroup>
          <Label>Screenshots</Label>
          <FileInput
            type="file"
            accept="image/*"
            multiple
            onChange={e => setFiles({
              ...files,
              screenshots: Array.from(e.target.files || [])
            })}
          />
        </FormGroup>

        <SubmitButton type="submit">Update App</SubmitButton>
      </form>
    </UpdateFormContainer>
  );
};

const UpdateFormContainer = styled.div`
  background: white;
  padding: 24px;
  border-radius: 12px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);

  h2 {
    margin: 0 0 24px 0;
    color: #333;
  }
`;

const FormGroup = styled.div`
  margin-bottom: 20px;
`;

const Label = styled.label`
  display: block;
  margin-bottom: 8px;
  font-weight: 600;
  color: #444;
`;

const Input = styled.input`
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;

  &:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 0 2px rgba(0,123,255,0.25);
  }
`;

const Select = styled.select`
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  background-color: white;

  &:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 0 2px rgba(0,123,255,0.25);
  }
`;

const TextArea = styled.textarea`
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  min-height: 100px;
  resize: vertical;

  &:focus {
    outline: none;
    border-color: #007bff;
    box-shadow: 0 0 0 2px rgba(0,123,255,0.25);
  }
`;

const FileInput = styled.input`
  width: 100%;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  background-color: white;

  &::file-selector-button {
    padding: 8px 16px;
    border: none;
    border-radius: 4px;
    background-color: #007bff;
    color: white;
    cursor: pointer;
    margin-right: 16px;
    
    &:hover {
      background-color: #0056b3;
    }
  }
`;

const SubmitButton = styled(Button)`
  width: 100%;
  padding: 12px;
  background-color: #28a745;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;

  &:hover {
    background-color: #218838;
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  }

  &:active {
    transform: translateY(0);
  }

  &:disabled {
    background-color: #6c757d;
    cursor: not-allowed;
  }
`;

export default UpdateApp; 