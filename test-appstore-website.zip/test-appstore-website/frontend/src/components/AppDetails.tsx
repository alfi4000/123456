import React from 'react';
import { IApp } from '../types';
import { Button, VersionCard } from './StyledComponents';

interface AppDetailsProps {
  app: IApp;
  onClose: () => void;
}

const AppDetails: React.FC<AppDetailsProps> = ({ app, onClose }) => {
  const handleDownload = (apkFile: string) => {
    window.open(`http://192.168.50.96:3011${apkFile}`, '_blank');
  };

  return (
    <div className="app-details-modal">
      <div className="modal-header">
        <img src={`http://192.168.50.96:3011${app.icon}`} alt={app.name} className="app-icon-large" />
        <div>
          <h2>{app.name}</h2>
          <p>{app.description}</p>
          <p>Developer: {app.developer}</p>
        </div>
        <Button onClick={onClose}>Close</Button>
      </div>

      <div className="versions-list">
        <h3>Available Versions</h3>
        {app.versions.sort((a, b) => 
          new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime()
        ).map(version => (
          <VersionCard key={version.versionNumber}>
            <div className="version-header">
              <h4>Version {version.versionNumber}</h4>
              <span>{new Date(version.uploadDate).toLocaleDateString()}</span>
            </div>
            <p>{version.changelog}</p>
            <div className="screenshots">
              {version.screenshots.map((screenshot, index) => (
                <img 
                  key={index}
                  src={`http://192.168.50.96:3011${screenshot}`}
                  alt={`Screenshot ${index + 1}`}
                  className="screenshot-thumb"
                />
              ))}
            </div>
            <Button onClick={() => handleDownload(version.apkFile)}>
              Download APK
            </Button>
          </VersionCard>
        ))}
      </div>
    </div>
  );
};

export default AppDetails; 