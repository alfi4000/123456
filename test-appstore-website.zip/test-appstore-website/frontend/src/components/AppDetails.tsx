import React from 'react';
import { IApp } from '../types';
import { Button, VersionCard } from './StyledComponents';
import { API_URL } from '../config';
import styled from 'styled-components';

interface AppDetailsProps {
  app: IApp;
  onClose: () => void;
}

const AppDetails: React.FC<AppDetailsProps> = ({ app, onClose }) => {
  const handleDownload = (apkFile: string, appName: string, versionNumber: string) => {
    try {
      if (!apkFile) {
        throw new Error('APK file path is undefined');
      }

      const cleanPath = apkFile.replace(/^\//, '');
      if (!cleanPath) {
        throw new Error('Invalid APK file path');
      }

      const downloadUrl = `${API_URL}/${cleanPath}`;
      const link = document.createElement('a');
      link.href = downloadUrl;
      link.download = `${appName}-version-${versionNumber}.apk`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Download error:', error);
      alert('Error downloading file');
    }
  };

  const currentVersion = app.versions[0];

  return (
    <AppDetailsContainer>
      <CloseButton onClick={onClose}>Back</CloseButton>
      
      <AppHeader>
        <AppBasicInfo>
          <AppIcon src={`${API_URL}${app.icon || ''}`} alt={app.name} />
          <AppMainInfo>
            <AppTitle>{app.name}</AppTitle>
            <DeveloperInfo>
              <Label>Developer:</Label>
              <Value>{app.developer}</Value>
            </DeveloperInfo>
            <VersionInfo>
              <Label>Current Version:</Label>
              <Value>{currentVersion?.versionNumber}</Value>
            </VersionInfo>
            <DownloadButton
              onClick={() =>
                currentVersion &&
                handleDownload(currentVersion.apkFile, app.name, currentVersion.versionNumber)
              }
              disabled={!currentVersion?.apkFile}
            >
              Download Latest Version
            </DownloadButton>
          </AppMainInfo>
        </AppBasicInfo>

        <AppDescription>
          <Label>Description:</Label>
          <Value>{app.description}</Value>
        </AppDescription>

        {currentVersion?.screenshots.length > 0 && (
          <CurrentScreenshots>
            <Label>Latest Screenshots:</Label>
            <ScreenshotsGrid>
              {currentVersion.screenshots.map((screenshot, index) => (
                <Screenshot
                  key={index}
                  src={`${API_URL}${screenshot || ''}`}
                  alt={`Screenshot ${index + 1}`}
                  onClick={() => window.open(`${API_URL}${screenshot || ''}`, '_blank')}
                />
              ))}
            </ScreenshotsGrid>
          </CurrentScreenshots>
        )}
      </AppHeader>

      <VersionsSection>
        <SectionTitle>Version History</SectionTitle>
        <VersionsList>
          {app.versions
            .slice(1)
            .map(version => (
              <VersionCard key={version.versionNumber}>
                <VersionHeader>
                  <VersionDetails>
                    <VersionNumber>Version {version.versionNumber}</VersionNumber>
                    <ReleaseDate>{new Date(version.uploadDate).toLocaleDateString()}</ReleaseDate>
                  </VersionDetails>
                  <DownloadButton onClick={() => handleDownload(version.apkFile, app.name, version.versionNumber)}>
                    Download
                  </DownloadButton>
                </VersionHeader>
                
                {version.changelog && (
                  <ChangelogSection>
                    <Label>Changelog:</Label>
                    <Changelog>{version.changelog}</Changelog>
                  </ChangelogSection>
                )}

                {version.screenshots.length > 0 && (
                  <ScreenshotsSection>
                    <Label>Screenshots:</Label>
                    <Screenshots>
                      {version.screenshots.map((screenshot, index) => (
                        <Screenshot
                          key={index}
                          src={`${API_URL}${screenshot}`}
                          alt={`Screenshot ${index + 1}`}
                          onClick={() => window.open(`${API_URL}${screenshot}`, '_blank')}
                        />
                      ))}
                    </Screenshots>
                  </ScreenshotsSection>
                )}
              </VersionCard>
            ))}
        </VersionsList>
      </VersionsSection>
    </AppDetailsContainer>
  );
};

const AppDetailsContainer = styled.div`
  padding: 30px;
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
  position: relative;
`;

const CloseButton = styled(Button)`
  position: absolute;
  top: 20px;
  left: 20px;
  padding: 8px 16px;
  z-index: 10;
`;

const AppHeader = styled.div`
  margin-top: 40px;
  display: flex;
  flex-direction: column;
  gap: 24px;
`;

const AppBasicInfo = styled.div`
  display: flex;
  gap: 24px;
  align-items: flex-start;
`;

const AppIcon = styled.img`
  width: 120px;
  height: 120px;
  border-radius: 16px;
  object-fit: cover;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`;

const AppMainInfo = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 12px;
`;

const AppTitle = styled.h1`
  margin: 0;
  font-size: 28px;
  color: #333;
`;

const Label = styled.span`
  font-weight: 600;
  color: #666;
  margin-right: 8px;
`;

const Value = styled.span`
  color: #333;
`;

const DeveloperInfo = styled.div`
  display: flex;
  align-items: center;
`;

const VersionInfo = styled.div`
  display: flex;
  align-items: center;
`;

const AppDescription = styled.div`
  background: #f8f9fa;
  padding: 16px;
  border-radius: 8px;
  margin-top: 16px;
`;

const CurrentScreenshots = styled.div`
  margin-top: 20px;
`;

const ScreenshotsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
  gap: 16px;
  margin-top: 12px;
`;

const VersionsSection = styled.div`
  margin-top: 40px;
`;

const SectionTitle = styled.h2`
  color: #333;
  margin-bottom: 20px;
  padding-bottom: 8px;
  border-bottom: 2px solid #f0f0f0;
`;

const VersionsList = styled.div`
  display: flex;
  flex-direction: column;
  gap: 20px;
`;

const VersionHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16px;
`;

const VersionDetails = styled.div`
  display: flex;
  flex-direction: column;
  gap: 4px;
`;

const VersionNumber = styled.h3`
  margin: 0;
  color: #333;
`;

const ReleaseDate = styled.span`
  color: #666;
  font-size: 0.9em;
`;

const ChangelogSection = styled.div`
  margin: 16px 0;
`;

const Changelog = styled.p`
  margin: 8px 0;
  white-space: pre-line;
  color: #444;
`;

const ScreenshotsSection = styled.div`
  margin-top: 16px;
`;

const Screenshots = styled.div`
  display: flex;
  gap: 16px;
  overflow-x: auto;
  padding: 12px 0;
  scrollbar-width: thin;
  
  &::-webkit-scrollbar {
    height: 6px;
  }
  
  &::-webkit-scrollbar-track {
    background: #f0f0f0;
  }
  
  &::-webkit-scrollbar-thumb {
    background: #888;
    border-radius: 3px;
  }
`;

const Screenshot = styled.img`
  height: 180px;
  border-radius: 8px;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);

  &:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 8px rgba(0,0,0,0.2);
  }
`;

const DownloadButton = styled(Button)`
  background: #28a745;
  padding: 10px 20px;
  border-radius: 6px;
  font-weight: 600;
  transition: all 0.2s;

  &:hover {
    background: #218838;
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  }

  &:active {
    transform: translateY(0);
  }
`;

export default AppDetails; 