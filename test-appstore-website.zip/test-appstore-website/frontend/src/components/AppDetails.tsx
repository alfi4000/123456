import React from 'react';
import { IApp } from '../types';
import { Button, VersionCard } from './StyledComponents';
import { API_URL } from '../config';
import styled from 'styled-components';

interface AppDetailsProps {
  app: IApp;
  onClose: () => void;
}

const AppDetails: React.FC<AppDetailsProps> = ({ app, onClose }) => {
  const handleDownload = (apkFile: string) => {
    window.open(`${API_URL}${apkFile}`, '_blank');
  };

  const handleLatestDownload = () => {
    if (app.versions.length > 0) {
      handleDownload(app.versions[0].apkFile);
    }
  };

  return (
    <AppDetailsContainer>
      <Header>
        <CloseButton onClick={onClose}>Back</CloseButton>
        <AppIcon src={`${API_URL}${app.icon}`} alt={app.name} />
        <AppInfo>
          <h2>{app.name}</h2>
          <p>{app.description}</p>
          <p>Developer: {app.developer}</p>
          <DownloadButton onClick={handleLatestDownload}>
            Download Latest Version
          </DownloadButton>
        </AppInfo>
      </Header>

      <VersionsList>
        <h3>Available Versions</h3>
        {app.versions
          .sort((a, b) => new Date(b.uploadDate).getTime() - new Date(a.uploadDate).getTime())
          .map(version => (
            <VersionCard key={version.versionNumber}>
              <VersionHeader>
                <VersionInfo>
                  <h4>Version {version.versionNumber}</h4>
                  <span>{new Date(version.uploadDate).toLocaleDateString()}</span>
                </VersionInfo>
                <DownloadButton onClick={() => handleDownload(version.apkFile)}>
                  Download APK
                </DownloadButton>
              </VersionHeader>
              <Changelog>{version.changelog}</Changelog>
              <Screenshots>
                {version.screenshots.map((screenshot, index) => (
                  <Screenshot
                    key={index}
                    src={`${API_URL}${screenshot}`}
                    alt={`Screenshot ${index + 1}`}
                    onClick={() => window.open(`${API_URL}${screenshot}`, '_blank')}
                  />
                ))}
              </Screenshots>
            </VersionCard>
          ))}
      </VersionsList>
    </AppDetailsContainer>
  );
};

const AppDetailsContainer = styled.div`
  padding: 20px;
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
`;

const Header = styled.div`
  display: grid;
  grid-template-columns: auto 100px 1fr;
  gap: 20px;
  align-items: start;
  margin-bottom: 30px;
  position: relative;
`;

const CloseButton = styled(Button)`
  position: absolute;
  top: 0;
  left: 0;
  padding: 8px 16px;
`;

const AppIcon = styled.img`
  width: 100px;
  height: 100px;
  border-radius: 12px;
  object-fit: cover;
`;

const AppInfo = styled.div`
  h2 {
    margin: 0 0 10px 0;
  }
  p {
    margin: 5px 0;
  }
`;

const VersionsList = styled.div`
  h3 {
    margin-bottom: 20px;
  }
`;

const VersionHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
`;

const VersionInfo = styled.div`
  h4 {
    margin: 0;
  }
  span {
    color: #666;
    font-size: 0.9em;
  }
`;

const Changelog = styled.p`
  margin: 10px 0;
  white-space: pre-line;
`;

const Screenshots = styled.div`
  display: flex;
  gap: 10px;
  overflow-x: auto;
  padding: 10px 0;
`;

const Screenshot = styled.img`
  height: 150px;
  border-radius: 8px;
  cursor: pointer;
  transition: transform 0.2s;

  &:hover {
    transform: scale(1.05);
  }
`;

const DownloadButton = styled(Button)`
  background: #28a745;
  &:hover {
    background: #218838;
  }
`;

export default AppDetails; 