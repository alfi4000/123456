import mongoose, { Schema, Document } from 'mongoose';

export interface IApp extends Document {
  name: string;
  packageName: string;
  description: string;
  developer: string;
  icon: string;
  versions: {
    versionNumber: string;
    versionCode: number;
    changelog: string;
    apkFile: string;
    screenshots: string[];
    uploadDate: Date;
  }[];
  createdAt: Date;
  updatedAt: Date;
}

const AppSchema: Schema = new Schema({
  name: { type: String, required: true },
  packageName: { type: String, required: true, unique: true },
  description: { type: String, required: true },
  developer: { type: String, required: true },
  icon: { type: String },
  versions: [{
    versionNumber: { type: String, required: true },
    versionCode: { type: Number, required: true, min: 1 },
    changelog: { type: String },
    apkFile: { type: String, required: true },
    screenshots: [{ type: String }],
    uploadDate: { type: Date, default: Date.now }
  }]
}, {
  timestamps: true
});

export default mongoose.model<IApp>('App', AppSchema); 