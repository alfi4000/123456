import express from 'express';
import cors from 'cors';
import multer from 'multer';
import path from 'path';
import mongoose from 'mongoose';
import App from './models/App';
import fs from 'fs';

const app = express();
const port = 3011;

// MongoDB connection
mongoose.connect(process.env.MONGODB_URI || 'mongodb://root:example@mongodb:27017/appstore?authSource=admin', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
} as mongoose.ConnectOptions)
  .then(() => console.log('Connected to MongoDB'))
  .catch((err: Error) => console.error('MongoDB connection error:', err));

app.use(cors({
  origin: process.env.CORS_ORIGIN || 'http://192.168.50.191:8033',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'Content-Length', 'X-Requested-With'],
  exposedHeaders: ['Content-Length', 'X-Requested-With']
}));
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (_req, file, cb) => {
    const uploadDir = file.fieldname === 'apk' ? 'uploads/apks' : 'uploads/images';
    cb(null, uploadDir);
  },
  filename: (_req, file, cb) => {
    const uniqueSuffix = `${Date.now()}-${Math.round(Math.random() * 1E9)}`;
    cb(null, `${file.fieldname}-${uniqueSuffix}${path.extname(file.originalname)}`);
  }
});

const upload = multer({ storage });

// Routes
app.get('/api/apps', async (_req, res) => {
  try {
    const apps = await App.find().select('-versions.apkFile');
    return res.json(apps);
  } catch (error) {
    const err = error as Error;
    console.error('Error fetching apps:', err);
    return res.status(500).json({ error: 'Error fetching apps', details: err.message });
  }
});

app.post('/api/apps', upload.fields([
  { name: 'apk', maxCount: 1 },
  { name: 'icon', maxCount: 1 },
  { name: 'screenshots', maxCount: 5 }
]), async (req, res) => {
  try {
    const files = req.files as { [fieldname: string]: Express.Multer.File[] };
    const appData = JSON.parse(req.body.appData);

    if (!files.apk) {
      return res.status(400).json({ error: 'APK file is required' });
    }

    const newApp = new App({
      name: appData.name,
      packageName: appData.packageName,
      description: appData.description,
      developer: appData.developer,
      icon: files.icon ? `/uploads/images/${files.icon[0].filename}` : undefined,
      versions: [{
        versionNumber: appData.versionNumber,
        versionCode: appData.versionCode,
        changelog: appData.changelog,
        apkFile: `/uploads/apks/${files.apk[0].filename}`,
        screenshots: files.screenshots 
          ? files.screenshots.map(file => `/uploads/images/${file.filename}`)
          : [],
      }]
    });

    await newApp.save();
    return res.status(201).json(newApp);
  } catch (error) {
    const err = error as Error;
    console.error('Error creating app:', err);
    return res.status(500).json({ 
      error: 'Error creating app',
      details: err.message 
    });
  }
});

app.delete('/api/apps/:id/versions/:versionNumber', async (req, res) => {
  try {
    const app = await App.findById(req.params.id);
    if (!app) {
      return res.status(404).json({ error: 'App not found' });
    }

    const versionIndex = app.versions.findIndex(
      v => v.versionNumber === req.params.versionNumber
    );

    if (versionIndex === -1) {
      return res.status(404).json({ error: 'Version not found' });
    }

    // Remove the version
    app.versions.splice(versionIndex, 1);
    await app.save();

    return res.status(204).send();
  } catch (error) {
    const err = error as Error;
    console.error('Error deleting version:', err);
    return res.status(500).json({ error: 'Error deleting version', details: err.message });
  }
});

app.delete('/api/apps/:id', async (req, res) => {
  try {
    await App.findByIdAndDelete(req.params.id);
    return res.status(204).send();
  } catch (error) {
    const err = error as Error;
    console.error('Error deleting app:', err);
    return res.status(500).json({ error: 'Error deleting app', details: err.message });
  }
});

// Ensure upload directories exist
const dirs = ['uploads', 'uploads/apks', 'uploads/images'];
dirs.forEach(dir => {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
});

app.listen(port, '0.0.0.0', () => {
  console.log(`Backend server running at http://192.168.50.191:${port}`);
}); 